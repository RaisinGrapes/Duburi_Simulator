Movements -> W,A,S,D
Turns -> Right, Left arrow
Up and Down -> Up and Down Arrow.

Change Camera - C